import argparse
import torch
def parse_args():
    parser = argparse.ArgumentParser(description="Reinforce Model Configuration")
    parser.add_argument("--dataset_name", type=str, choices=["xlong", "taobao", "tmall", "KuaiRand"], default="xlong",
                        help="Name of the dataset to use")
    parser.add_argument("--model_name", type=str, default="Adaptuive_compression_model",
                        help="Name of the model (default: Adaptuive_compression_model)")
    parser.add_argument("--seed", type=int, default=52,
                        help="Random seed (default: 52)")
    parser.add_argument("--BATCH_SIZE", type=int, default=512,
                        help="Batch size (default: 512)")
    parser.add_argument("--EPOCHS", type=int, default=10,
                        help="Number of training epochs (default: 10)")
    parser.add_argument("--simple_embedding_dim", type=int, default=16,
                        help="Simple embedding dimension (default: 16)")
    parser.add_argument("--heads", type=int, default=8,
                        help="Number of attention heads (default: 8)")
    parser.add_argument("--layers1", type=int, default=1,
                        help="Number of layers in module 1 (default: 1)")
    parser.add_argument("--layers2", type=int, default=1,
                        help="Number of layers in module 2 (default: 1)")
    parser.add_argument("--drop_out", type=float, default=0.5,
                        help="Dropout rate (default: 0.5)")
    parser.add_argument("--device_id", type=int, default=0,
                        help="GPU device ID (default: 0)")
    parser.add_argument("--compressed", action="store_true", default=True,
                        help="Whether to use compressed representation (default: True)")
    parser.add_argument("--second_compressed", action="store_true", default=True,
                        help="Whether to use second-stage compression (default: True)")
    parser.add_argument("--hidden_size", type=int, default=128,
                        help="Hidden layer size (default: 128)")
    parser.add_argument("--chose_epoch", type=int, default=0,
                        help="Chosen epoch for evaluation time varience (default: 0)")

    args = parser.parse_args()

    if args.dataset_name == "xlong":
        args.total_behavior_num =  1000
        args.id_embedding_dim =  16
        args.interest_num =  4
        args.group_num =  80
        args.short_time =  20
    elif args.dataset_name == "tmall":
        args.total_behavior_num =  1000
        args.id_embedding_dim =  64
        args.interest_num = 1
        args.group_num =  80
        args.short_time =  20
    elif args.dataset_name == "KuaiRand":
        args.total_behavior_num = 8000
        args.id_embedding_dim = 64
        args.interest_num = 1
        args.group_num =  800
        args.short_time = 50
    
    args.device = f"cuda:{args.device_id}" if torch.cuda.is_available() else "cpu"

    return args

if __name__ == "__main__":
    args = parse_args()
    print("Parsed arguments:")
    for k, v in vars(args).items():
        print(f"{k}: {v}")