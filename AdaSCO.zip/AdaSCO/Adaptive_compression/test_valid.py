#coding=utf-8
import time
import torch
import random
import warnings
import numpy as np
from torch.utils.data import DataLoader
from sklearn.metrics import roc_auc_score
from config import *
from dataset import *
from models.Adaptive_compression_model import *
warnings.filterwarnings('ignore')

def set_seed(seed_value):
    random.seed(seed_value)
    np.random.seed(seed_value)
    torch.manual_seed(seed_value)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed_value)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
    
def main(args):
    if args.dataset_name == "xlong":
        data_path = "../data/xlong"
        test_data = XLongDataset(data_path, mode="test", nrows=args.n_users)
        val_data = None
    elif args.dataset_name == "tmall":
        test_target_item_file = '../data/tmall/final_test_data.csv'
        valid_target_item_file = '../data/tmall/final_valid_data.csv'
        user_behavior_file = '../data/tmall/800_user_actions.csv'
        test_data = TmallDataset(test_target_item_file, user_behavior_file,
                                mode='test', n_users=args.n_users,
                                behaviors_num=args.total_behavior_num)
        val_data = TmallDataset(valid_target_item_file, user_behavior_file,
                                mode='valid', n_users=args.n_users,
                                behaviors_num=args.total_behavior_num)
    elif args.dataset_name == "KuaiRand":
        test_target_item_file = '../data/KuaiRand/data/final_test_data.csv'
        valid_target_item_file = '../data/KuaiRand/data/final_valid_data.csv'

        user_behavior_file = '../data/KuaiRand/data/8000_user_actions.csv'
        test_data = KuaiRandDataset(test_target_item_file, user_behavior_file,
                                    mode='test', n_users=args.n_users,
                                    behaviors_num=args.total_behavior_num)
        val_data = KuaiRandDataset(valid_target_item_file, user_behavior_file,
                                    mode='valid', n_users=args.n_users,
                                    behaviors_num=args.total_behavior_num)
    else:
        print(f"{args.dataset_name}数据集不存在")
        exit()

    test_loader = DataLoader(test_data, batch_size=args.BATCH_SIZE, shuffle=True)
    if val_data is not None:
        valid_loader = DataLoader(val_data, batch_size=args.BATCH_SIZE, shuffle=True)
    else:
        valid_loader = None

    print("Parsed arguments:")
    for k, v in vars(args).items():
        print(f"{k}: {v}")

    device = args.device
    model = Adaptive_Compress_Model(args)
    model = model.to(device)
    origin_criterion = nn.CrossEntropyLoss().to(device)

    times = []
    for i in range(args.EPOCHS):
        checkpoint = torch.load(f"checkpoints/{args.dataset_name}_{args.model_name}_{i}.pth", weights_only=False)
        model.load_state_dict(checkpoint['model_state_dict'])
        if val_data is not None:
            total_val_len = len(val_data)
        total_test_len = len(test_data)
        with torch.no_grad():
            accuracy = 0
            auc_list = []
            valid_loss = 0
            if valid_loader is not None:
                start_time = time.time()
                for target_item, behaviors, target in valid_loader:
                    target_item = target_item.to(device)
                    behaviors = behaviors.to(device)
                    target = target.to(device)
                    pred_y= model(behaviors,target_item)[0].float().to(device)
                    valid_loss += origin_criterion(pred_y, target)
                    y_pred_prob_positive = pred_y[:, 1].cpu().detach().numpy()
                    if len(set(target.cpu().numpy())) > 1:
                        auc = roc_auc_score(target.cpu().numpy(), y_pred_prob_positive)
                        auc_list.append(auc)
                    accuracy += (torch.argmax(pred_y, dim=-1) == target).sum().cpu().item()
                total_acc = accuracy / total_val_len
                auc = np.mean(auc_list)
                print(f"{i} epoch: valid_log_loss:{float(valid_loss) / (len(test_data) / args.BATCH_SIZE)} valid_acc :{total_acc}, valid_auc :{auc}")
                times.append(int(time.time()-start_time))
            accuracy = 0
            pred_list = []
            target_list = []
            test_loss = 0
            start_time = time.time()
            for target_item, behaviors, target in test_loader:
                target_item = target_item.to(device)
                behaviors = behaviors.to(device)
                target = target.to(device)
                pred_y= model(behaviors,target_item)[0].float().to(device)
                test_loss += origin_criterion(pred_y, target)
                pred_list.append(pred_y[:, 1].cpu())
                target_list.append(target.cpu())
                accuracy += (torch.argmax(pred_y, dim=-1) == target).sum().cpu().item()
            total_acc = accuracy / total_test_len
            all_y_pred = torch.concat(pred_list,dim=0).numpy()
            all_target = torch.concat(target_list, dim=0).numpy()
            total_auc = roc_auc_score(all_target, all_y_pred)
            print(f"{i} epoch: test_log_loss:{float(test_loss) / (len(test_data) / args.BATCH_SIZE)} test_acc :{total_acc}, test_auc :{total_auc}")
            times.append(int(time.time()-start_time))
        print(f"reinforce_compression in {args.dataset_name}average inference time:{np.mean(times)}s")

if __name__ == '__main__':
    print("-"*20)
    set_seed(args.seed)
    args = parse_args()
    main(args)
