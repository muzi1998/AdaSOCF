import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_scatter import segment_coo
from torch.distributions import Categorical
from models.Modules import *

class Adaptive_Compress_Model(nn.Module):
    def __init__(self,
                 args):
        super().__init__()
        self.vocab_size_dic = args.vocab_size_dic
        self.total_behavior_num = args.total_behavior_num
        self.heads = args.heads
        self.short_time = args.short_time
        self.layers1 = args.layers1
        self.layers2 = args.layers2
        self.group_num = args.group_num
        self.compressed = args.compressed
        self.second_compressed = args.second_compressed
        self.interest_num = args.interest_num
        self.embedding = Embedding(args.vocab_size_dic,
                                   args.id_embedding_dim,
                                   args.simple_embedding_dim)
        self.embedding_dim = self.embedding.h + self.embedding.c
        if self.interest_num != 0:
            self.infer_num = self.interest_num
        else:
            self.infer_num = 1
        if self.compressed:
            self.compression = CompressionPolicyNetwork_MLP(self.embedding_dim,
                                                            self.group_num,
                                                            self.total_behavior_num-self.short_time,
                                                            hidden_dim=args.hidden_size)

            self.behavior_num = self.group_num + self.short_time
        else:
            self.behavior_num = self.total_behavior_num

        if self.interest_num != 0:
            self.q_gen = nn.Linear(self.total_behavior_num, self.interest_num, bias=False)
        
        if self.second_compressed:
            self.compress_transformers = nn.Sequential(
                *[Casual_Transformer(self.embedding_dim,
                                    self.heads,
                                    self.behavior_num - self.short_time,
                                    self.short_time,
                                    args.drop_out,
                                    self_att=False)
                for _ in range(self.layers1)]
            )        
        
        self.infer_net = Kuai_Inf(self.embedding_dim,
                                self.heads,
                                self.behavior_num,
                                self.short_time,
                                args.drop_out,
                                self.layers1,
                                self.layers2,
                                self.interest_num,
                                self.second_compressed,
                                )
        self._init_weights()
    
    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Embedding):
                nn.init.xavier_normal_(m.weight)

    def get_atten(self, behaviors):
        ts = self.embedding(behaviors)
        if self.compressed:
            short_time_ts = ts[:, -self.short_time:,:]
            ts, _ = self.compression(ts[:,:-self.short_time,:])
            ts = torch.concat([ts, short_time_ts], dim=-2)
        if self.second_compressed:
            early_behaviors = ts[:, :-self.short_time,:]
            latest_behaviors = ts[:, -self.short_time:,:]
            behaviors = (latest_behaviors, early_behaviors)
            _, _, atten = self.compress_transformers(behaviors)
        else:
            atten = None
        return atten
    
    def get_seg_pos(self,behaviors):
        ts = self.embedding(behaviors)
        return self.compression.get_seg_pos(ts[:, :self.total_behavior_num-self.short_time,:])

    def get_compressed_sim(self,behaviors):
        b = behaviors.shape[0]
        ts = self.embedding(behaviors)
        _, _ ,sim = self.compression(ts[:,:-self.short_time,:])
        return sim.mean().item()

    def forward(self, behaviors, target_item):
        b = behaviors.shape[0]
        target_embed = self.embedding(target_item)
        if len(target_embed.shape) == 2:
            target_embed = target_embed.unsqueeze(1)
        ts = self.embedding(behaviors)

        if self.interest_num != 0:
            interest_embed = self.q_gen(ts.transpose(1,2)).transpose(1,2)
        else:
            interest_embed = None

        if self.compressed:
            short_time_ts = ts[:, -self.short_time:,:]
            ts, compress_loss, _ = self.compression(ts[:,:-self.short_time,:])
            ts = torch.concat([ts, short_time_ts], dim=-2)
        else:
            compress_loss = 0
        if self.second_compressed:
            early_behaviors = ts[:, :-self.short_time,:]
            latest_behaviors = ts[:, -self.short_time:,:]
            behaviors = (latest_behaviors, early_behaviors)
            final_ts, _, _ = self.compress_transformers(behaviors)
        else:
            final_ts = ts

        y = self.infer_net(final_ts, target_embed, interest_embed)

        return y, compress_loss
    

