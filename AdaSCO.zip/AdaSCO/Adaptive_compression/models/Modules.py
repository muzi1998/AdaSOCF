import math
import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from math import sqrt
from torch_scatter import segment_coo
from torch.distributions import Categorical

class Embedding(nn.Module):
    def __init__(self,
                 vocab_size_dic,
                 id_embedding_dim=64,
                 simple_embedding_dim=8,
                 ):
        """
        :param vocab_size_dic: 字典，存储用户行为中的各个特征以及其vocab size
                                    格式-->{
                                            'inherent_feature':{'item_id':vocab_num, 'author':vocab_num,...},
                                            'cross_feature':{'play_time':vocab_num, 'date':vocab_num,...}
                                        }
        :param id_embedding_dim: vocab 数量多的特征的embed dim
        :param simple_embedding_dim: vocab 数量少的embed dim
        """
        super(Embedding, self).__init__()
        self.vocab_size_dic = vocab_size_dic
        self.simple_embedding_dim = simple_embedding_dim
        self.id_embedding_dim = id_embedding_dim
        vocab_num_list = [] 
        h = 0
        for feature, vocab_num in vocab_size_dic['inherent_feature'].items():
            if 'id' in feature:
                vocab_num_list.append((vocab_num, id_embedding_dim))
                h += id_embedding_dim
            else:
                vocab_num_list.append((vocab_num, simple_embedding_dim))
                h += simple_embedding_dim
        c = 0
        for feature,vocab_num  in vocab_size_dic['cross_feature'].items():
            if 'id' in feature:
                vocab_num_list.append((vocab_num, id_embedding_dim))
                c += id_embedding_dim
            else:
                vocab_num_list.append((vocab_num, simple_embedding_dim))
                c += simple_embedding_dim

        self.h = h
        self.c = c
        self.vocab_size_list = [vocab_num for vocab_num, _ in vocab_num_list]
        self.embed_layer_dic = nn.ModuleDict()
        for idx, (vocab_num, embed_dim) in enumerate(vocab_num_list):
            if embed_dim == id_embedding_dim:
                layer_name = 'item_id_embedding_{}'.format(idx)
            else:
                layer_name = str(idx)
            self.embed_layer_dic[layer_name] = nn.Embedding(vocab_num, embed_dim)

    def forward(self, s):
        embed_list = []
        index = 0
        for embed_layer in self.embed_layer_dic.values():
            input = s.narrow(-1, start=index, length=1)
            embed_list.append(embed_layer(input).squeeze(-2))
            index += 1
            if index >= s.shape[-1]:
                break
        final_embed = torch.cat(embed_list, dim=-1)
        return final_embed

class CompressionPolicyNetwork_MLP(nn.Module):
    def __init__(self, embedding_dim, group_num, seq_len,gradient_gather=True,hidden_dim=10):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(seq_len, hidden_dim, bias=False),
            nn.ReLU6(),
            nn.Linear(hidden_dim, seq_len, bias=False),
            nn.ReLU6(),
        )
        self.atte_head1 = nn.Sequential(
            nn.Linear(seq_len, hidden_dim, bias=False),
            nn.ReLU6(),
            nn.Linear(hidden_dim, seq_len, bias=False),
            nn.ReLU6(),
        )
        self.atte_head2 = nn.Sequential(
            nn.Linear(embedding_dim,1,bias=False),
            nn.ReLU6()
        )
        self.group_num = group_num - 1
        self.gradient_gather = gradient_gather
        self.logits_head = nn.Linear(embedding_dim, 1)
    
    def get_seg_pos(self, embeddings):
        device = embeddings.device
        batch_size, seq_len = embeddings.shape[:2]
        encoder_emb = self.encoder(embeddings.transpose(1,2)).transpose(1,2)  # (batch_size, seq_len, embedding_dim)
        logits = self.logits_head(encoder_emb).squeeze(-1)  # (batch_size, seq_len)
        selected = torch.zeros((batch_size, 0), dtype=torch.long, device=device)
        log_probs = []
        for _ in range(self.group_num):
            if selected.size(1) > 0:
                mask = torch.zeros_like(logits, dtype=torch.bool)
                src = torch.ones_like(selected, dtype=torch.bool)
                mask.scatter_(1, selected, src)
            else:
                mask = torch.zeros_like(logits, dtype=torch.bool)
            masked_logits = logits.masked_fill(mask, -1e9)
            probs = F.softmax(masked_logits, dim=-1)
            dist = Categorical(probs)
            action = dist.sample()
            log_probs.append(dist.log_prob(action))
            selected = torch.cat([selected, action.unsqueeze(1)], dim=1)
        device = embeddings.device
        batch_size, seq_len, embed_dim = embeddings.shape
        sorted_pos, _ = torch.sort(selected, dim=-1)
        boundaries = torch.cat([
            torch.zeros(batch_size, 1, device=device, dtype=torch.long),
            sorted_pos,
            torch.full((batch_size, 1), seq_len, device=device, dtype=torch.long)
        ], dim=-1)  
        pos_grid = torch.arange(seq_len, device=device).expand(batch_size, -1)
        segment_idx = []
        for i in range(batch_size):
            _segment_idx = torch.bucketize(pos_grid[i], boundaries[i], right=True) - 1
            segment_idx.append(_segment_idx.unsqueeze(-1))
        segment_idx = torch.concat(segment_idx, dim = -1).T
        return segment_idx

    def forward(self, embeddings):
        device = embeddings.device
        batch_size, seq_len = embeddings.shape[:2]
        encoder_emb = self.encoder(embeddings.transpose(1,2)).transpose(1,2)  # (batch_size, seq_len, embedding_dim)
        atte_score = self.atte_head1(embeddings.transpose(1,2)).transpose(1,2)
        atte_score = self.atte_head2(atte_score)
        logits = self.logits_head(encoder_emb).squeeze(-1)  # (batch_size, seq_len)
        selected = torch.zeros((batch_size, 0), dtype=torch.long, device=device)
        log_probs = []
        for _ in range(self.group_num):
            if selected.size(1) > 0:
                mask = torch.zeros_like(logits, dtype=torch.bool)
                src = torch.ones_like(selected, dtype=torch.bool)
                mask.scatter_(1, selected, src)
            else:
                mask = torch.zeros_like(logits, dtype=torch.bool)
            masked_logits = logits.masked_fill(mask, -1e9)
            probs = F.softmax(masked_logits, dim=-1)
            dist = Categorical(probs)
            action = dist.sample()
            log_probs.append(dist.log_prob(action))
            selected = torch.cat([selected, action.unsqueeze(1)], dim=1)

        log_probs = torch.stack(log_probs, -1).sum(-1)
        rewards, avg_emb = self.compute_rewards(embeddings, selected,atte_score)
        compress_loss = -(log_probs * rewards).mean()
        return avg_emb, compress_loss,rewards

    def compute_rewards(self,embeddings, selected_positions,atte_score):
        device = embeddings.device
        batch_size, seq_len, embed_dim = embeddings.shape
        atte_score = torch.exp(atte_score)
        k = selected_positions.size(1)
        sorted_pos, _ = torch.sort(selected_positions, dim=-1)
        boundaries = torch.cat([
            torch.zeros(batch_size, 1, device=device, dtype=torch.long),
            sorted_pos,
            torch.full((batch_size, 1), seq_len, device=device, dtype=torch.long)
        ], dim=-1) 
        pos_grid = torch.arange(seq_len, device=device).expand(batch_size, -1)
        segment_idx = []
        for i in range(batch_size):
            _segment_idx = torch.bucketize(pos_grid[i], boundaries[i], right=True) - 1
            segment_idx.append(_segment_idx.unsqueeze(-1))
        segment_idx = torch.concat(segment_idx, dim = -1).T
        flat_emb = embeddings.reshape(-1, embed_dim)
        flat_seg = segment_idx + (torch.arange(batch_size, device=device) * (k+1)).unsqueeze(-1)
        flat_seg = flat_seg.reshape(-1)
        atte_score = atte_score.reshape(-1,1)
        sum_atte_score = segment_coo(atte_score, flat_seg, dim_size=batch_size*(k+1), reduce='sum').reshape(batch_size,-1,1)
        sum_atte_score = sum_atte_score.gather(1, segment_idx.unsqueeze(-1)).reshape(-1,1)
        atte_score = atte_score / sum_atte_score
        flat_emb = flat_emb * atte_score
        avg_emb = segment_coo(flat_emb, flat_seg, dim_size=batch_size*(k+1), reduce='sum')
        avg_emb = avg_emb.view(batch_size, k+1, embed_dim)
        expanded_avg = avg_emb.gather(1, segment_idx.unsqueeze(-1).expand(-1, -1, embed_dim))
        similarities = F.cosine_similarity(embeddings, expanded_avg, dim=-1).mean(dim=-1)
        return similarities, avg_emb

class Self_Attention(nn.Module):
    def __init__(self,
                 embedding_dim,
                 sequence_len,
                 heads,
                 q_num = 0,
                 drop_out=0.2,
                 ):
        super().__init__()
        self.head_dim = embedding_dim // heads
        self.embedding_dim = embedding_dim
        self.q_num = q_num
        assert heads * self.head_dim == embedding_dim
        self.w_q = nn.Linear(self.head_dim, self.head_dim)
        self.w_k = nn.Linear(self.head_dim, self.head_dim)
        self.w_v = nn.Linear(self.head_dim, self.head_dim)
        self.w_o = nn.Linear(embedding_dim, embedding_dim)
        self.drop_out = nn.Dropout(drop_out)
        self.softmax = nn.Softmax(dim=-1)
        self.heads = heads
        self.sequence_len = sequence_len
        self.total_sequence_len = sequence_len + q_num
        self.input_mask = self.get_mask()
        self.sqrt_d_out = math.sqrt(self.head_dim)

    def rope(self, x):
        base = 10000
        d = self.embedding_dim
        inv_freq = 1.0 / (base ** (torch.arange(0, d, 2) / d).float())
        seq_len = self.sequence_len
        seq_id = torch.arange(seq_len).float()
        id_theta = torch.einsum("m,d->md", seq_id, inv_freq)
        id_theta2 = torch.concat((id_theta, id_theta), dim=1)
        cos_cache = id_theta2.cos().to(x.device)
        sin_cache = id_theta2.sin().to(x.device)

        def rotate_half(_x):
            x1 = _x[..., :d // 2]
            x2 = _x[..., d // 2:]
            return torch.concat([-x2, x1], dim=-1)

        rotated_x = rotate_half(x)
        return (torch.concat([x[:,:seq_len,:]*cos_cache, x[:,seq_len:,:]],dim=1)
                + torch.concat([rotated_x[:,:seq_len,:]*sin_cache, x[:,seq_len:,:]], dim=1))

    def forward(self, input):
        b = input.shape[0]
        queries = self.rope(input).view(b, -1, self.heads, self.head_dim)
        keys = self.rope(input).view(b, -1, self.heads, self.head_dim)
        values = input.view(b, -1, self.heads, self.head_dim)

        queries = self.w_q(queries)
        keys = self.w_k(keys)
        values = self.w_v(values)
        energy = torch.einsum("nqhd,nkhd->nhqk", [queries, keys])

        self.input_mask = self.input_mask.to(input.device)
        energy = energy.masked_fill_(~self.input_mask, -1 * np.inf)

        atte = self.softmax(energy / self.sqrt_d_out)
        atte = self.drop_out(atte)
        out = torch.einsum("nhql,nlhd->nqhd", [atte, values]).reshape(
            b, self.total_sequence_len, self.embedding_dim
        )
        return self.w_o(out)


    def get_mask(self):
        total_q_num = self.total_sequence_len - self.sequence_len
        mask = ((torch.triu(torch.ones(self.total_sequence_len, self.total_sequence_len)) == 1)
                .transpose(0, 1)).squeeze(0)
        mask.requires_grad = False
        return mask

class Cross_Attention(nn.Module):
    def __init__(self, 
                 embedding_dim, 
                 q_len, 
                 kv_len,
                 heads,
                 drop_out=0.2):
        super().__init__()
        assert embedding_dim % heads == 0,(
            "embedding_dim 应该能被 heads整除"
        )
        self.embedding_dim = embedding_dim
        self.heads = heads
        self.q_len = q_len
        self.kv_len = kv_len
        self.head_dim = int(embedding_dim / heads)
        self.wq = nn.Linear(self.head_dim, self.head_dim,bias=False)
        self.wk = nn.Linear(self.head_dim, self.head_dim,bias=False)
        self.wv = nn.Linear(self.head_dim, self.head_dim,bias=False)
        self.dropout = nn.Dropout(drop_out)
        self.wo = nn.Linear(embedding_dim, embedding_dim)
        self.softmax = nn.Softmax(dim=-1)
        self.sqrt_d = sqrt(self.head_dim)

    def rope(self, x, seq_len):
            base = 10000
            d = self.embedding_dim
            inv_freq = 1.0 / (base ** (torch.arange(0, d, 2) / d).float())
            seq_id = torch.arange(seq_len).float()
            id_theta = torch.einsum("m,d->md", seq_id, inv_freq)
            id_theta2 = torch.concat((id_theta, id_theta), dim=1)
            cos_cache = id_theta2.cos().to(x.device)
            sin_cache = id_theta2.sin().to(x.device)
            def rotate_half(_x):
                x1 = _x[..., :d // 2]
                x2 = _x[..., d // 2:]
                return torch.concat([-x2, x1], dim=-1)

            rotated_x = rotate_half(x)
            return (torch.concat([x[:,:seq_len,:]*cos_cache, x[:,seq_len:,:]],dim=1)
                    + torch.concat([rotated_x[:,:seq_len,:]*sin_cache, x[:,seq_len:,:]], dim=1))

    def forward(self,q , kv):
        batch_size, seq_len , embedding_dim = kv.size()
        q = self.rope(q, self.q_len).view(batch_size, -1, self.heads, self.head_dim)
        k = self.rope(kv, self.kv_len).view(batch_size, -1, self.heads, self.head_dim)
        v = kv.view(batch_size, -1, self.heads, self.head_dim)
        query = self.wq(q)
        keys = self.wk(k)
        values = self.wv(v)

        atte = torch.einsum("bqhd,bkhd->bhqk",[query,keys])
        atte = self.softmax(atte / self.sqrt_d)
        ret_atte = atte
        atte = self.dropout(atte)
        out = torch.einsum("bhqk, bkhd->bqhd",[atte,values]).reshape(
            batch_size, self.q_len, self.embedding_dim
        )
        return self.wo(out) ,kv,ret_atte

class RMSNorm(nn.Module):
    def __init__(self,normalized_shape, eps=1e-8):
        super(RMSNorm, self).__init__()
        self.eps = eps
        if isinstance(normalized_shape, int):
            normalized_shape = (normalized_shape,)
        self.weight = nn.Parameter(torch.ones(normalized_shape))

    def forward(self, x):
        mean_square = torch.mean(x ** 2, dim = -1,keepdim=True)
        x_normalized = x / torch.sqrt(mean_square + self.eps)
        return self.weight * x_normalized

class MLP(nn.Module):
    def __init__(self, in_feature):
        super().__init__()
        self.ln1 = nn.Linear(in_feature, in_feature*3,bias=False)
        self.ln2 = nn.Linear(in_feature, in_feature*3,bias=False)
        self.activate_fn = nn.ReLU()
        self.ln3 = nn.Linear(in_feature*3, in_feature,bias=False)

    def forward(self,x):
        gate_pro_out = self.activate_fn(self.ln1(x))
        up_pro_out = self.ln2(x)
        return self.ln3(gate_pro_out * up_pro_out)

class Casual_Transformer(nn.Module):
    def __init__(self,
                 embedding_dim,
                 heads,
                 kv_len,
                 q_len,
                 drop_out=0.2,
                 self_att =False,
                 interest_num = 1,
                 ):
        super().__init__()
        self.embedding_dim = embedding_dim
        self.heads = heads
        self.kv_len = kv_len
        self.q_len = q_len
        self.self_att = self_att
        self.atten_norm = RMSNorm(embedding_dim)
        self.mlp_norm = RMSNorm(embedding_dim)
        if self_att:
            self.mmhsa = Self_Attention(embedding_dim,
                                        q_len,
                                        heads,
                                        q_num=interest_num,
                                        drop_out=drop_out)
            self.q_num = interest_num
        else:
            self.mmhsa = Cross_Attention(embedding_dim,
                                        q_len,
                                        kv_len,
                                        heads,
                                        drop_out=drop_out)
            self.q_num = interest_num
        
        self.mlp = MLP(embedding_dim)

    def forward(self, qkv):
        if not self.self_att and not self.diff_att:
            if len(qkv) == 2:
                q, kv = qkv
            elif len(qkv) == 3:
                q, kv, _ =qkv
            else:
                exit()
            hidden_state, _, atten = self.mmhsa(self.atten_norm(q), self.atten_norm(kv))
            hidden_state = q + hidden_state
            q = hidden_state + self.mlp(self.mlp_norm(hidden_state))
            return q, kv, atten
        else:
            hidden_state = self.mmhsa(self.atten_norm(qkv))
            hidden_state = qkv + hidden_state
            qkv = hidden_state + self.mlp(self.mlp_norm(hidden_state))
            return qkv

class Kuai_Inf(nn.Module):
    def __init__(self,
                 embedding_dim,
                 heads,
                 behavior_num,
                 short_time,
                 drop_out,
                 layers1,
                 layers2,
                 interest_num,
                 second_compressed):
        super().__init__()
        self.embedding_dim = embedding_dim
        self.heads = heads
        self.behavior_num = behavior_num
        self.short_time = short_time
        self.drop_out = drop_out
        self.layers1 = layers1
        self.layers2 = layers2
        self.interest_num = interest_num
        self.second_compressed = second_compressed
        if self.interest_num != 0:
            self.infer_num = self.interest_num
        else:
            self.infer_num = 1
        if self.second_compressed:
            self.infer_transformers = nn.Sequential(
                *[Casual_Transformer(self.embedding_dim,
                                    self.heads,
                                    self.short_time,
                                    self.short_time,
                                    self.drop_out,
                                    self_att=True,
                                    interest_num=self.interest_num,
                                    diff_att=False,
                                    )
                for _ in range(self.layers2)]
            )

        else:
            self.infer_transformers = nn.Sequential(
                *[Casual_Transformer(self.embedding_dim,
                                    self.heads,
                                    self.behavior_num,
                                    self.behavior_num,
                                    self.drop_out,
                                    self_att=True,
                                    interest_num=self.interest_num
                                    )
                for _ in range(self.layers2)]
            )
        self.ff = nn.Sequential(
            nn.Linear(self.infer_num, self.infer_num*4),
            nn.GELU(),
            nn.Linear(self.infer_num *4, self.infer_num),
            nn.GELU(),
            nn.Linear(self.infer_num, 2),
            nn.Softmax(dim=-1)
        )
    def forward(self,final_ts,target_embed, interest_embed=None):
        b = final_ts.shape[0]
        if self.interest_num != 0:
            behaviors = torch.concat([ final_ts,interest_embed],dim=-2)
        else:
            behaviors = final_ts
        interest_repre = self.infer_transformers(behaviors)[:,-1 * self.infer_num:,:]
        if len(interest_repre.shape) == 2:
            interest_repre = interest_repre.unsqueeze(1)
        y = self.ff(torch.einsum("bie,bje->bij",[target_embed, interest_repre]).reshape(b,-1))
        return y

