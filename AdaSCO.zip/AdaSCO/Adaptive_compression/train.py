#coding=utf-8
import os
import time
import torch
import random
import warnings
import numpy as np
import torch.optim as optim
from torch.utils.data import DataLoader
from sklearn.metrics import roc_auc_score
from config import *
from dataset import *
from models.Adaptive_compression_model import *
warnings.filterwarnings('ignore')
def set_seed(seed_value):
    random.seed(seed_value)
    np.random.seed(seed_value)
    torch.manual_seed(seed_value)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed_value)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True

def main(args):
    if args.dataset_name == "xlong":
        data_path = "../data/xlong"
        train_data = XLongDataset(data_path, nrows=args.n_users)
    elif args.dataset_name == "tmall":
        train_target_item_file = '../data/tmall/final_train_data.csv'
        user_behavior_file = '../data/tmall/800_user_actions.csv'
        train_data = TmallDataset(train_target_item_file, user_behavior_file,
                                mode='train', n_users=args.n_users,
                                behaviors_num=args.total_behavior_num)
    elif args.dataset_name == "KuaiRand":
        train_target_item_file = '../data/KuaiRand/data/final_train_data.csv'
        user_behavior_file = '../data/KuaiRand/data/8000_user_actions.csv'
        train_data = KuaiRandDataset(train_target_item_file, user_behavior_file,
                                    mode='train', n_users=args.n_users,
                                    behaviors_num=args.total_behavior_num)
    else:
        print(f"{args.dataset_name}数据集不存在")
        exit()

    device = args.device
    print("Parsed arguments:")
    for k, v in vars(args).items():
        print(f"{k}: {v}")

    model = Adaptive_Compress_Model(args)

    if args.dataset_name == "xlong":
        weight = torch.tensor(np.loadtxt("../data/xlong/graph_emb.txt"), dtype=torch.float32)
        model.embedding.embed_layer_dic['item_id_embedding_0'].weight.data = weight
    model = model.to(device)

    total_num = len(train_data)
    lr = 1e-3
    weight_decay = 1e-4
    compress_lambda = 1e-5
    dataloader = DataLoader(train_data, batch_size=args.BATCH_SIZE, shuffle=True)
    origin_criterion = nn.CrossEntropyLoss().to(device)
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)

    times = []
    for epoch in range(0,args.EPOCHS):
        model.train()
        accuracy = 0
        cur_data_num = 0
        train_loss_ = 0
        aucs = []
        start_time=time.time()
        for idx, (target_item, behaviors, target) in enumerate(dataloader):
            cur_data_num += args.BATCH_SIZE
            target_item = target_item.to(device)
            behaviors = behaviors.to(device)
            target = target.to(device)
            pred_y, compress_loss = model(behaviors,target_item)
            pred_y = pred_y.float().to(device)
            train_loss = origin_criterion(pred_y,target)
            train_loss += compress_loss * compress_lambda
            accuracy += (torch.argmax(pred_y, dim=-1) == target).sum().cpu().item()
            y_pred_prob_positive = pred_y[:, 1].cpu().detach().numpy()
            if len(set(target.cpu().numpy())) > 1:
                auc = roc_auc_score(target.cpu().detach().numpy(), y_pred_prob_positive)
            else:
                auc = 0.5
            aucs.append(auc)
            cur_acc = accuracy / cur_data_num
            optimizer.zero_grad()
            train_loss.backward()
            optimizer.step()
            train_loss_ += train_loss.detach() * len(behaviors)
            if idx % 50 == 0:
                print("{} epoch {} step training loss:{}, acc:{}, auc:{}".format(epoch + 1,
                                                                                 idx + 1,
                                                                                 train_loss,
                                                                                 cur_acc,
                                                                                 np.mean(auc)))
        total_acc = accuracy / total_num
        total_train_loss = train_loss_ / total_num
        auc = np.mean(aucs)
        print("{} epoch finish training loss:{}, acc:{}, auc:{}".format(epoch + 1, total_train_loss, total_acc,
                                                                        auc))
        times.append(int(time.time()-start_time))
        if not os.path.exists("./checkpoints/"):
            os.mkdir("./checkpoints/")
        if args.n_users is None :
            torch.save({
                'epoch':epoch+1,
                'model_state_dict':model.state_dict(),
            }, "./checkpoints/{}_{}_{}.pth".format(args.dataset_name,args.model_name,epoch))
    print(f"reinforce_compression in {args.dataset_name} average train time:",np.mean(times),"s")
    return auc


if __name__ == '__main__':
    args = parse_args()
    set_seed(args.seed)
    main(args)
