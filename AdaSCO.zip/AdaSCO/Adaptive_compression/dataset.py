import ast
import json
import torch
import os.path
import numpy as np
import pandas as pd
from random import randint
from torch.utils.data import Dataset, DataLoader

class TmallDataset(Dataset):
    def __init__(self,
                 train_target_item_file,
                 user_behavior_file, mode,
                 behaviors_num=1000,
                 n_users=None
                 ):
        print(f"tmall {mode} dataset 准备")
        self.behaviors_num = behaviors_num
        use_columns = ['user_id','item_id','category','brand_id','seller_id','sub_category','vtime']
        self.train_target_item = pd.read_csv(train_target_item_file, nrows=n_users).iloc[:, 1:]
        self.user_behavior = pd.read_csv(user_behavior_file, usecols=use_columns, nrows=n_users)
        self.user_behavior['item_id'] = self.user_behavior['item_id'].apply(ast.literal_eval)
        self.user_behavior['category'] = self.user_behavior['category'].apply(ast.literal_eval)
        self.user_behavior['brand_id'] = self.user_behavior['brand_id'].apply(ast.literal_eval)
        self.user_behavior['seller_id'] = self.user_behavior['seller_id'].apply(ast.literal_eval)
        self.user_behavior['sub_category'] = self.user_behavior['sub_category'].apply(ast.literal_eval)
        self.user_behavior['vtime'] = self.user_behavior['vtime'].apply(ast.literal_eval)
        max_time = 0
        min_time = 0
        for timestamps in self.user_behavior.loc[:, 'vtime']:
            _max_time = max(timestamps)
            _min_time = min(timestamps)
            if _max_time > max_time:
                max_time = _max_time
            if _min_time < min_time:
                min_time = _min_time

        time_bucket_num = (max_time - min_time) // 3600 + 1
        self.time_bucket_num = time_bucket_num
        self.min_time = min_time
        self.mode = mode

        with open('../data/tmall/brand_id2idx.json', 'r', encoding='utf-8') as f:
            self.brand_id2idx = json.load(f)
        with open('../data/tmall/category2idx.json', 'r', encoding='utf-8') as f:
            self.category2idx = json.load(f)
        with open('../data/tmall/item_id2idx.json', 'r', encoding='utf-8') as f:
            self.item_id2idx = json.load(f)
        with open('../data/tmall/seller_id2idx.json', 'r', encoding='utf-8') as f:
            self.seller_id2idx = json.load(f)
        with open('../data/tmall/sub_category2idx.json', 'r', encoding='utf-8') as f:
            self.sub_category2idx = json.load(f)

        self.vocab_size_dic = {
            "inherent_feature": {
                "item_id": len(self.item_id2idx) + 1,
                "category_id": len(self.category2idx) + 1,
                "sub_category_id": len(self.sub_category2idx) + 1,
                "seller_id": len(self.seller_id2idx) + 1,
                "brand_id": len(self.brand_id2idx) + 1,
            },
            "cross_feature": {
                "vtime": time_bucket_num + 1
            }
        }
        print("准备完成")

    def get_time_bucket(self, time_stamp):
        return (time_stamp - self.min_time) // 3600 + 1

    def __getitem__(self, index):
        user_id,target_item_id,target_category,target_brand_id,target_seller_id,target_sub_category,target_vtime,target = self.train_target_item.iloc[index]
        if target == 0:
            target_vtime -= 10
        behaviors = []
        behavior_items = list(self.user_behavior[self.user_behavior['user_id'] == user_id]\
                              .iloc[0,1:])

        if self.mode == 'train':
            try:
                target_item_loc = list(behavior_items[-1]).index(target_vtime)
            except ValueError:
                target_item_loc = -1
        elif self.mode == 'test':
            target_item_loc = -1
        else:
            target_item_loc = -1

        for index, behavior in enumerate(
                zip(behavior_items[0][target_item_loc + 1:],
                    behavior_items[1][target_item_loc + 1:],
                    behavior_items[2][target_item_loc + 1:],
                    behavior_items[3][target_item_loc + 1:],
                    behavior_items[4][target_item_loc + 1:],
                    behavior_items[5][target_item_loc + 1:]
                    )):
            behavior_item_id = self.item_id2idx[str(behavior[0])]
            behavior_item_category = self.category2idx[str(behavior[1])]
            behavior_item_brand = self.brand_id2idx[str(behavior[2])]
            behavior_item_seller = self.seller_id2idx[str(behavior[3])]
            behavior_item_subcategory = self.sub_category2idx[str(behavior[4])]
            behavior_item_vtime = self.get_time_bucket(behavior[5])
            behaviors.append([behavior_item_id, behavior_item_category,
                              behavior_item_subcategory,behavior_item_seller,
                              behavior_item_brand,behavior_item_vtime])

        if len(behaviors) >= self.behaviors_num:
            behaviors = behaviors[:self.behaviors_num]
        else:
            if self.behaviors_num > 5000:
                for i in range(self.behaviors_num - len(behaviors)):
                    behaviors.append([randint(0, self.vocab_size_dic['inherent_feature']['item_id'] - 1),
                                      randint(0, self.vocab_size_dic['inherent_feature']['category_id'] - 1),
                                      randint(0, self.vocab_size_dic['inherent_feature']['sub_category_id'] - 1),
                                      randint(0, self.vocab_size_dic['inherent_feature']['seller_id'] - 1),
                                      randint(0, self.vocab_size_dic['inherent_feature']['brand_id'] - 1),
                                      randint(0, self.vocab_size_dic['cross_feature']['vtime'] - 1)])
            else:
                for i in range(self.behaviors_num - len(behaviors)):
                    behaviors.append([0, 0, 0,0,0,0])

        assert len(behaviors) == self.behaviors_num
        target_item_id = self.item_id2idx[str(target_item_id)]
        target_category = self.category2idx[str(target_category)]
        target_brand_id = self.brand_id2idx[str(target_brand_id)]
        target_seller_id = self.seller_id2idx[str(target_seller_id)]
        target_sub_category = self.sub_category2idx[str(target_sub_category)]
        target_vtime = self.get_time_bucket(target_vtime)
        target_item = torch.tensor([target_item_id,
                                    target_category,
                                    target_sub_category,
                                    target_seller_id,
                                    target_brand_id,
                                    target_vtime]).long()
        target = torch.tensor(target).long()
        behaviors = torch.tensor(behaviors).long()
        return target_item, behaviors, target

    def __len__(self):
        return len(self.train_target_item)

class XLongDataset(Dataset):
    def __init__(self, data_path,behavior_num=1000, mode='train',nrows=None,q_num = 4):
        assert mode == 'train' or mode == 'test'
        print(f"XLong {mode}数据集读取中")
        self.data = pd.read_csv(os.path.join(data_path, f"final_{mode}_data.csv"),sep='\t', nrows=nrows)
        self.data['item_seq'] = self.data['item_seq'].apply(ast.literal_eval)
        self.mode = mode
        self.behavior_num = behavior_num
        self.embedding_num = 0
        self.q_num = q_num
        for l in self.data.loc[:, 'item_seq']:
            _max = np.max(l)
            if _max > self.embedding_num:
                self.embedding_num = _max

        self.vocab_size_dic = {
            "inherent_feature": {
                "item_id": self.embedding_num+1,
            },
            "cross_feature": {
            }
        }
        print("读取完毕")

    def __getitem__(self, item):
        uid, behaviors, target_item, target = self.data.iloc[item]
        behaviors = list(behaviors)
        if len(behaviors) > self.behavior_num:
            behaviors = behaviors[:self.behavior_num]
        elif len(behaviors) < self.behavior_num:
            for _ in range(self.behavior_num - len(behaviors)):
                behaviors.append(self.embedding_num+1)
        target_item = torch.tensor(target_item).long().unsqueeze(-1)
        behaviors = torch.tensor(behaviors).long().unsqueeze(-1)
        target = torch.tensor(target)
        return target_item, behaviors,target
    def __len__(self):
        return len(self.data)


class KuaiRandDataset(Dataset):
    def __init__(self,
                 train_target_item_file,
                 user_behavior_file, mode,
                 behaviors_num=1000,
                 n_users=None
                 ):
        print(f"KuaiRand {mode} dataset 准备")
        self.behaviors_num = behaviors_num
        use_columns = ['user_id', 'video_id', 'time_ms', 'is_click', 'is_like', 'is_follow', 'is_comment', 'is_forward', 'is_hate', 'long_view', 'is_profile_enter','tab','author_id','video_type']
        self.train_target_item = pd.read_csv(train_target_item_file, usecols=use_columns+['inter_type'], nrows=n_users)
        self.user_behavior = pd.read_csv(user_behavior_file, usecols=use_columns, nrows=n_users)
        self.user_behavior['video_id'] = self.user_behavior['video_id'].apply(ast.literal_eval)
        self.user_behavior['time_ms'] = self.user_behavior['time_ms'].apply(ast.literal_eval)
        self.user_behavior['is_click'] = self.user_behavior['is_click'].apply(ast.literal_eval)
        self.user_behavior['is_like'] = self.user_behavior['is_like'].apply(ast.literal_eval)
        self.user_behavior['is_follow'] = self.user_behavior['is_follow'].apply(ast.literal_eval)
        self.user_behavior['is_comment'] = self.user_behavior['is_comment'].apply(ast.literal_eval)
        self.user_behavior['is_forward'] = self.user_behavior['is_forward'].apply(ast.literal_eval)
        self.user_behavior['is_hate'] = self.user_behavior['is_hate'].apply(ast.literal_eval)
        self.user_behavior['long_view'] = self.user_behavior['long_view'].apply(ast.literal_eval)
        self.user_behavior['is_profile_enter'] = self.user_behavior['is_profile_enter'].apply(ast.literal_eval)
        self.user_behavior['tab'] = self.user_behavior['tab'].apply(ast.literal_eval)
        self.user_behavior['author_id'] = self.user_behavior['author_id'].apply(ast.literal_eval)
        self.user_behavior['video_type'] = self.user_behavior['video_type'].apply(ast.literal_eval)
        self.mode = mode
        max_time = 0
        min_time = 0
        for timestamps in self.user_behavior.loc[:, 'time_ms']:
            _max_time = max(timestamps)
            _min_time = min(timestamps)
            if _max_time > max_time:
                max_time = _max_time
            if _min_time < min_time:
                min_time = _min_time

        time_bucket_num = (max_time - min_time) // 3600 + 1
        self.time_bucket_num = time_bucket_num
        self.min_time = min_time

        with open('../data/KuaiRand/data/author_id2idx.json', 'r', encoding='utf-8') as f:
            self.author_id2idx = json.load(f)
        with open('../data/KuaiRand/data/music_id2idx.json', 'r', encoding='utf-8') as f:
            self.music_id2idx = json.load(f)
        with open('../data/KuaiRand/data/video_id2idx.json', 'r', encoding='utf-8') as f:
            self.video_id2idx = json.load(f)

        self.vocab_size_dic = {
            "inherent_feature": {
                "video_id": len(self.video_id2idx) + 1,
                "author_id": len(self.author_id2idx) + 1,
                "video_type": 4
            },
            "cross_feature": {
                "time_ms":time_bucket_num+1,
                "is_click": 2,
                "is_like": 2,
                "is_follow": 2,
                "is_comment": 2,
                "is_forward": 2,
                "is_hate": 2,
                "long_view": 2,
                "is_profile_enter": 2,
                "tab": 16,
            }
        }
        print("准备完成")

    def get_time_bucket(self, time_stamp):
        return (time_stamp - self.min_time) // 3600 + 1

    def __getitem__(self, index):
        (user_id, target_video_id, target_time_ms, target_is_click, target_is_like, target_is_follow, target_is_comment,
         target_is_forward, target_is_hate, target_long_view, target_is_profile_enter, target_tab, target_author_id,
         target_video_type,target) = \
        self.train_target_item.iloc[index]

        behaviors = []

        behavior_items = list(self.user_behavior[self.user_behavior['user_id'] == user_id] .iloc[0, 1:])
        
        if target == 0:
            target_time_ms -= 10

        try:
            target_item_loc = list(behavior_items[2]).index(target_time_ms)
            if int(target) == 1:
                target_item_loc = list(behavior_items[0][target_item_loc:]).index(target_video_id)
        except ValueError:
            target_item_loc = -1
    
        for index, behavior in enumerate(
                zip(behavior_items[0][target_item_loc + 1:],
                    behavior_items[1][target_item_loc + 1:],
                    behavior_items[2][target_item_loc + 1:],
                    behavior_items[3][target_item_loc + 1:],
                    behavior_items[4][target_item_loc + 1:],
                    behavior_items[5][target_item_loc + 1:],
                    behavior_items[6][target_item_loc + 1:],
                    behavior_items[7][target_item_loc + 1:],
                    behavior_items[8][target_item_loc + 1:],
                    behavior_items[9][target_item_loc + 1:],
                    behavior_items[10][target_item_loc + 1:],
                    behavior_items[11][target_item_loc + 1:],
                    behavior_items[12][target_item_loc + 1:],
                    )):
            if str(behavior[0]) not in self.video_id2idx:
                behavior_video_id = 0
            else:
                behavior_video_id = self.video_id2idx[str(int(behavior[0]))]
            behavior_time_ms = self.get_time_bucket(behavior[1])
            behavior_is_click = behavior[2]
            behavior_is_like = behavior[3]
            behavior_is_follow = behavior[4]
            behavior_is_comment = behavior[5]
            behavior_is_forward = behavior[6]
            behavior_is_hate = behavior[7]
            behavior_long_view = behavior[8]
            behavior_is_profile_enter = behavior[9]
            behavior_tab = behavior[10]
            if str(behavior[11]) not in self.author_id2idx:
                behavior_author_id = 0
            else:
                behavior_author_id = self.author_id2idx[str(int(behavior[11]))]
            behavior_video_type = behavior[12]

            behaviors.append([behavior_video_id, behavior_author_id,behavior_video_type,
                              behavior_time_ms, behavior_is_click,behavior_is_like,behavior_is_follow,behavior_is_comment,
                              behavior_is_forward, behavior_is_hate,behavior_long_view,behavior_is_profile_enter,behavior_tab])

        if len(behaviors) >= self.behaviors_num:
            behaviors = behaviors[:self.behaviors_num]
        else:
            if self.behaviors_num > 10000:
                for i in range(self.behaviors_num - len(behaviors)):
                    behaviors.append([randint(0, self.vocab_size_dic['inherent_feature']['video_id'] - 1),
                                      randint(0, self.vocab_size_dic['inherent_feature']['author_id'] - 1),
                                      randint(0, self.vocab_size_dic['inherent_feature']['video_type'] - 1),
                                      randint(0, self.vocab_size_dic['cross_feature']['time_ms'] - 1),
                                      randint(0, self.vocab_size_dic['cross_feature']['is_click'] - 1),
                                      randint(0, self.vocab_size_dic['cross_feature']['is_like'] - 1),
                                      randint(0, self.vocab_size_dic['cross_feature']['is_follow'] - 1),
                                      randint(0, self.vocab_size_dic['cross_feature']['is_comment'] - 1),
                                      randint(0, self.vocab_size_dic['cross_feature']['is_forward'] - 1),
                                      randint(0, self.vocab_size_dic['cross_feature']['is_hate'] - 1),
                                      randint(0, self.vocab_size_dic['cross_feature']['long_view'] - 1),
                                      randint(0, self.vocab_size_dic['cross_feature']['is_profile_enter'] - 1),
                                      randint(0, self.vocab_size_dic['cross_feature']['tab'] - 1)])
            else:
                for i in range(self.behaviors_num - len(behaviors)):
                    behaviors.append([0, 0, 0, 0, 0, 0,0, 0, 0, 0, 0,0, 0])

        assert len(behaviors) == self.behaviors_num

        video_id_str = str(int(target_video_id))
        if video_id_str not in self.video_id2idx:
            # 处理缺失的情况
            import warnings
            warnings.warn(f"video_id {video_id_str} not found in video_id2idx")
            target_video_id = 0 
        else:
            target_video_id = self.video_id2idx[video_id_str]

        target_time_ms = self.get_time_bucket(target_time_ms)
        author_id_str = str(int(target_author_id))
        if author_id_str not in self.author_id2idx:
            # 处理缺失的情况
            import warnings
            warnings.warn(f"author_id {author_id_str} not found in author_id2idx")
            target_author_id = 0
        else:
            target_author_id = self.author_id2idx[author_id_str]
        
        target_item = torch.tensor([target_video_id,target_author_id,target_video_type,target_time_ms,
                                    target_is_click,target_is_like,target_is_follow,target_is_comment,
                                    target_is_forward,target_is_hate,target_long_view,target_is_profile_enter,target_tab
                                    ]).long()
        target = torch.tensor(target).long()
        behaviors = torch.tensor(behaviors).long()
        return target_item, behaviors, target

    def __len__(self):
        return len(self.train_target_item)
