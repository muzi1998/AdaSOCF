for dataset_name in xlong tmall
do
        for group_num in 260 200 140 80 20
        do
                python train.py --dataset_name $dataset_name --group_num $group_num >> log_files//train.log;
                python test_valid.py --dataset_name $dataset_name --group_num $group_num >> log_files//test_valid.log;
                if [ "$dataset_name" = "tmall" ];then
                        python print_seg_idx.py --dataset_name $dataset_name --group_num $group_num >> log_files//test_valid.log;
                fi
        done
done 
 
